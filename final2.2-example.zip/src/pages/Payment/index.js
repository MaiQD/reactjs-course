import { Typography } from "@mui/material";
import React from "react";
import MainLayout from "../../Layout/MainLayout";

export default function Payment() {
  return (
    <div>
      <MainLayout>
        <Typography variant="h3">Payment</Typography>
      </MainLayout>
    </div>
  );
}
